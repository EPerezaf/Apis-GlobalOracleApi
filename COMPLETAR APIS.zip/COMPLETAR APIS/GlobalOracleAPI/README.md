# GlobalOracleAPI
