using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.Contracts.Responses;
using Shared.Infrastructure;
using Shared.Security;
using Dapper;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics;

namespace GM.DealersSincronizacion.API.Controllers.ConnectionPool;

/// <summary>
/// Controller para realizar health check manual del pool de conexiones
/// </summary>
[ApiController]
[Route("api/v1/gm/dealer-sinc/connection-pool")]
[Produces("application/json")]
[Authorize]
public class PostConnectionPoolHealthCheckController : ControllerBase
{
    private readonly ILogger<PostConnectionPoolHealthCheckController> _logger;
    private readonly IServiceProvider _serviceProvider;
    private readonly Stopwatch _requestStopwatch;

    public PostConnectionPoolHealthCheckController(
        ILogger<PostConnectionPoolHealthCheckController> logger,
        IServiceProvider serviceProvider)
    {
        _logger = logger;
        _serviceProvider = serviceProvider;
        _requestStopwatch = Stopwatch.StartNew();
    }

    /// <summary>
    /// Realiza un health check manual del pool de conexiones.
    /// </summary>
    /// <remarks>
    /// Este endpoint verifica la salud de las conexiones Oracle ejecutando
    /// una consulta de validación (SELECT 1 FROM DUAL). Útil para monitoreo
    /// y diagnóstico de problemas de conectividad.
    /// 
    /// **Funcionalidad:**
    /// - Ejecuta una consulta de validación simple contra Oracle
    /// - Verifica que la conexión esté funcionando correctamente
    /// - Mide el tiempo de respuesta de la consulta
    /// - Retorna el estado de salud (Healthy/Unhealthy)
    /// 
    /// **Ejemplo de uso:**
    /// - POST /api/v1/gm/dealer-sinc/connection-pool/health-check
    /// 
    /// **Campos en la respuesta:**
    /// - `isHealthy`: Indica si la conexión está saludable (true si la consulta retornó 1)
    /// - `status`: Estado de la conexión ("Healthy" o "Unhealthy")
    /// - `responseTimeMs`: Tiempo de respuesta de la consulta en milisegundos
    /// - `timestamp`: Timestamp de la operación (hora de México)
    /// 
    /// **Validaciones:**
    /// - El usuario debe estar autenticado (JWT requerido)
    /// - La conexión Oracle debe estar disponible
    /// - Si la consulta falla, retorna isHealthy=false y status="Unhealthy"
    /// 
    /// **Respuesta exitosa incluye:**
    /// - Estado de salud de la conexión
    /// - Tiempo de respuesta de la consulta
    /// - Timestamp de la operación
    /// </remarks>
    /// <returns>Estado de salud del pool de conexiones</returns>
    /// <response code="200">Operación completada. Retorna estado de salud de la conexión.</response>
    /// <response code="401">No autorizado si no se proporciona un token JWT válido.</response>
    /// <response code="500">Error interno del servidor al realizar health check.</response>
    [HttpPost("health-check")]
    [ProducesResponseType(typeof(ApiResponse<object>), 200)]
    [ProducesResponseType(typeof(ApiResponse), 401)]
    [ProducesResponseType(typeof(ApiResponse), 500)]
    public async Task<IActionResult> PerformManualHealthCheck()
    {
        _requestStopwatch.Restart();
        _logger.LogInformation("🏥 Iniciando health check manual del pool de conexiones");

        try
        {
            using (var scope = _serviceProvider.CreateScope())
            {
                var connectionFactory = scope.ServiceProvider.GetRequiredService<IOracleConnectionFactory>();
                
                var healthStopwatch = Stopwatch.StartNew();
                using var connection = await connectionFactory.CreateConnectionAsync();
                var result = await connection.QueryFirstOrDefaultAsync<int>("SELECT 1 FROM DUAL");
                healthStopwatch.Stop();
                
                var isHealthy = result == 1;
                
                _requestStopwatch.Stop();
                
                _logger.LogInformation("🏥 Health check manual completado en {TiempoHealthCheck}ms - Status: {Status}", 
                    _requestStopwatch.ElapsedMilliseconds, isHealthy ? "Healthy" : "Unhealthy");

                return Ok(new ApiResponse<object>
                {
                    Success = true,
                    Data = new
                    {
                        IsHealthy = isHealthy,
                        Status = isHealthy ? "Healthy" : "Unhealthy",
                        ResponseTimeMs = healthStopwatch.ElapsedMilliseconds,
                        Timestamp = DateTimeHelper.GetMexicoDateTime()
                    },
                    Message = isHealthy ? "Health check completado - Conexión saludable" : "Health check completado - Conexión no saludable",
                    Timestamp = DateTimeHelper.GetMexicoTimeString()
                });
            }
        }
        catch (Exception ex)
        {
            _requestStopwatch.Stop();
            _logger.LogError(ex, "❌ Error en health check manual: {Error}", ex.Message);
            
            return StatusCode(500, new ApiResponse
            {
                Success = false,
                Message = "Error al realizar health check manual del pool de conexiones",
                Timestamp = DateTimeHelper.GetMexicoTimeString()
            });
        }
    }
}

